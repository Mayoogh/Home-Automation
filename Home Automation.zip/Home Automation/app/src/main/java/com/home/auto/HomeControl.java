package com.home.auto;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;

import java.io.IOException;
import java.util.UUID;


public class HomeControl extends ActionBarActivity {

    Switch l1, l2, l3, TV, fan, lock;
    ImageButton  Discnt, Abt;
    TextView txt_l1, txt_l2, txt_l3, txt_tv, txt_fan, txt_lock;
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(DeviceList.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the HomeControl
        setContentView(R.layout.activity_home_control);
        new ConnectBT().execute(); //Call the class to connect


      //  txt_l1.setVisibility(View.INVISIBLE);
      //  txt_l2.setVisibility(View.INVISIBLE);
      //  txt_l3.setVisibility(View.INVISIBLE);
      //  txt_fan.setVisibility(View.INVISIBLE);
      //  txt_lock.setVisibility(View.INVISIBLE);
      //  txt_tv.setVisibility(View.INVISIBLE);

        //call the widgets
        l1 = (Switch)findViewById(R.id.btn_light1);
        l2 = (Switch)findViewById(R.id.btn_light2);
        l3 = (Switch)findViewById(R.id.btn_light3);
        TV = (Switch)findViewById(R.id.btn_light4);
        fan = (Switch)findViewById(R.id.btn_fan);
        lock = (Switch)findViewById(R.id.btn_lock);
        Discnt = (ImageButton)findViewById(R.id.discnt);
        Abt = (ImageButton)findViewById(R.id.abt);
        Discnt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Disconnect(); //close connection
            }
        });
    }

    public void light1(View view)
    {
        txt_l1 = (TextView)findViewById(R.id.light1_text);
        boolean sw1 = ((Switch) view).isChecked();
        if(sw1)
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("0".toString().getBytes());
                    txt_l1.setText("Light 1 ON");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
        else
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("1".toString().getBytes());
                    txt_l1.setText("Light 1 OFF");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
    }

    public void  light2(View view)
    {
        txt_l2 = (TextView)findViewById(R.id.light2_text);
        boolean sw2 = ((Switch) view).isChecked();
        if(sw2)
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("2".toString().getBytes());
                    txt_l2.setText("Light 2 ON");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
        else
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("3".toString().getBytes());
                    txt_l2.setText("Light 2 OFF");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
    }

    public void  light3(View view)
    {
        txt_l3 = (TextView)findViewById(R.id.light3_text);
        boolean sw3 = ((Switch) view).isChecked();
        if(sw3)
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("4".toString().getBytes());
                    txt_l3.setText("Light 3 ON");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
        else
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("5".toString().getBytes());
                    txt_l3.setText("Light 3 OFF");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }

    }

    public void tv(View view)
    {
        txt_tv = (TextView)findViewById(R.id.TV_text);
        boolean sw4 = ((Switch) view).isChecked();
        if(sw4)
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("6".toString().getBytes());
                    txt_tv.setText("TV ON");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
        else
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("7".toString().getBytes());
                    txt_tv.setText("TV OFF");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
    }

    public void fan(View view)
    {
        txt_fan = (TextView)findViewById(R.id.fan_text);
        boolean sw5 = ((Switch) view).isChecked();
        if(sw5)
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("8".toString().getBytes());
                    txt_fan.setText("Fan ON");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
        else
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("9".toString().getBytes());
                    txt_fan.setText("Fan OFF");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
    }

    public void lock(View view) {
        txt_lock = (TextView)findViewById(R.id.lock_text);
        boolean sw6 = ((Switch) view).isChecked();
        if(sw6)
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("10".toString().getBytes());
                    txt_lock.setText("Locked");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
        else
        {
            if (btSocket!=null)
            {
                try
                {
                    btSocket.getOutputStream().write("11".toString().getBytes());
                    txt_lock.setText("Unlocked");

                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }
        }
    }



    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
            }
            catch (IOException e)
            { msg("Error");}
        }
        finish(); //return to the first layout

    }


    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }

    public  void about(View v)
    {
        if(v.getId() == R.id.abt)
        {
            Intent i = new Intent(this, AboutActivity.class);
            startActivity(i);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_led_control, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }




    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(HomeControl.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                 myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                 BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                 btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                 BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                 btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else
            {
                msg("Connected.");
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }
}
